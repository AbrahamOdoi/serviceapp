create view artisans as (select `db`.`Service_providers`.`id`           AS `id`,
                                `db`.`Service_providers`.`FirstName`    AS `FirstName`,
                                `db`.`Service_providers`.`LastName`     AS `LastName`,
                                `db`.`Service_providers`.`Email`        AS `Email`,
                                `db`.`Service_providers`.`address`      AS `address`,
                                `db`.`Service_providers`.`City`         AS `City`,
                                `db`.`Service_providers`.`Telephone_no` AS `Telephone_no`,
                                `db`.`services`.`serviceName`           AS `serviceName`,
                                `db`.`services`.`serviceDescription`    AS `serviceDescription`
                         from ((`db`.`services` join `db`.`Service_providers` on ((`db`.`Service_providers`.`Service` = `db`.`services`.`id`)))
                                join `db`.`UserType` on (((`db`.`UserType`.`UserType` = 'artisan') and
                                                          (`db`.`services`.`id` = `db`.`Service_providers`.`Service`)))));

