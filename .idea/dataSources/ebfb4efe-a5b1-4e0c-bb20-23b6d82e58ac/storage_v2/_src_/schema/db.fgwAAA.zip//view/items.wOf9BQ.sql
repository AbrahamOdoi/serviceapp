create view items as
select `db`.`shopItems`.`item`                 AS `item`,
       `db`.`shopItems`.`description`          AS `description`,
       `db`.`shopItems`.`price`                AS `price`,
       `db`.`shopItems`.`numberAvailable`      AS `numberAvailable`,
       `db`.`shopItems`.`id`                   AS `id`,
       `db`.`Service_providers`.`Telephone_no` AS `Telephone_no`,
       `db`.`Service_providers`.`City`         AS `City`,
       `db`.`Service_providers`.`Email`        AS `Email`,
       `db`.`Service_providers`.`LastName`     AS `LastName`,
       `db`.`Service_providers`.`FirstName`    AS `FirstName`,
       `db`.`Service_providers`.`shopName`     AS `shopName`,
       `db`.`Service_providers`.`address`      AS `address`,
       `db`.`Service_providers`.`id`           AS `shopId`
from (`db`.`shopItems`
       join `db`.`Service_providers` on ((`db`.`shopItems`.`shop` = `db`.`Service_providers`.`id`)));

