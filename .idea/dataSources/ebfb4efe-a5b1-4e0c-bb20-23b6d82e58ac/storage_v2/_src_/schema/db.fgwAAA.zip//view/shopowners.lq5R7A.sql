create view shopowners as (select `db`.`Service_providers`.`id`           AS `id`,
                                  `db`.`Service_providers`.`FirstName`    AS `FirstName`,
                                  `db`.`Service_providers`.`LastName`     AS `LastName`,
                                  `db`.`Service_providers`.`Email`        AS `Email`,
                                  `db`.`Service_providers`.`address`      AS `address`,
                                  `db`.`Service_providers`.`City`         AS `City`,
                                  `db`.`Service_providers`.`Telephone_no` AS `Telephone_no`,
                                  `db`.`Service_providers`.`shopName`     AS `shopName`
                           from (`db`.`Service_providers`
                                  join `db`.`UserType` on (((`db`.`UserType`.`UserType` = 'Shop Owner') and
                                                            (`db`.`UserType`.`id` = `db`.`Service_providers`.`User_type`)))));

