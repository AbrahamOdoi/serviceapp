create view sms_log as
select `wlhellio`.`logs`.`id`                                                                 AS `id`,
       `wlhellio`.`logs`.`bpid`                                                               AS `bpid`,
       `wlhellio`.`logs`.`job_id`                                                             AS `job_id`,
       `wlhellio`.`logs`.`user_id`                                                            AS `user_id`,
       `wlhellio`.`logs`.`username`                                                           AS `username`,
       `wlhellio`.`logs`.`msisdn`                                                             AS `msisdn`,
       `wlhellio`.`logs`.`network`                                                            AS `network`,
       `wlhellio`.`logs`.`sender`                                                             AS `sender`,
       `wlhellio`.`logs`.`h_message`                                                          AS `h_message`,
       `wlhellio`.`logs`.`message`                                                            AS `message`,
       `wlhellio`.`logs`.`sms_count`                                                          AS `sms_count`,
       `wlhellio`.`logs`.`submit_date`                                                        AS `submit_date`,
       `wlhellio`.`logs`.`created_by`                                                         AS `created_by`,
       `wlhellio`.`logs`.`response`                                                           AS `response`,
       `wlhellio`.`logs`.`originated`                                                         AS `originated`,
       `wlhellio`.`logs`.`refid`                                                              AS `refid`,
       `wlhellio`.`log_received`.`msgid`                                                      AS `msgid`,
       `wlhellio`.`log_received`.`delivery_time`                                              AS `delivery_time`,
       `wlhellio`.`log_received`.`error_code`                                                 AS `error_code`,
       `wlhellio`.`log_received`.`error_msg`                                                  AS `error_msg`,
       coalesce(`wlhellio`.`log_received`.`status`, `wlhellio`.`logs`.`status`)               AS `status`,
       coalesce(`wlhellio`.`log_received`.`delivery_date`, `wlhellio`.`logs`.`delivery_date`) AS `delivery_date`,
       `wlhellio`.`logs`.`created_at`                                                         AS `created_at`,
       `wlhellio`.`log_received`.`updated_at`                                                 AS `updated_at`
from (`wlhellio`.`logs`
       left join `wlhellio`.`log_received` on ((`wlhellio`.`logs`.`id` = `wlhellio`.`log_received`.`id`)))
where (`wlhellio`.`logs`.`user_id` is not null);

