create view client_request as (select `npontupay`.`clients`.`cllient_name`                      AS `cllient_name`,
                                      `npontupay`.`requests`.`id`                               AS `id`,
                                      `npontupay`.`requests`.`client_id`                        AS `client_id`,
                                      `npontupay`.`requests`.`msisdn`                           AS `msisdn`,
                                      `npontupay`.`requests`.`amount`                           AS `amount`,
                                      `npontupay`.`requests`.`voucher_number`                   AS `voucher_number`,
                                      `npontupay`.`requests`.`transaction_id`                   AS `transaction_id`,
                                      `npontupay`.`requests`.`client_timestamp`                 AS `client_timestamp`,
                                      `npontupay`.`requests`.`description`                      AS `description`,
                                      `npontupay`.`requests`.`pin`                              AS `pin`,
                                      `npontupay`.`requests`.`callback`                         AS `callback`,
                                      `npontupay`.`requests`.`status`                           AS `status`,
                                      `npontupay`.`requests`.`operator_id`                      AS `operator_id`,
                                      `npontupay`.`requests`.`created_at`                       AS `created_at`,
                                      `npontupay`.`requests`.`updated_at`                       AS `updated_at`,
                                      `npontupay`.`requests`.`operator_request_message`         AS `operator_request_message`,
                                      `npontupay`.`requests`.`operator_response_code`           AS `operator_response_code`,
                                      `npontupay`.`requests`.`operator_response_message`        AS `operator_response_message`,
                                      `npontupay`.`requests`.`operator_response_transaction_id` AS `operator_response_transaction_id`,
                                      `npontupay`.`requests`.`network`                          AS `network`,
                                      `npontupay`.`requests`.`token`                            AS `token`,
                                      `npontupay`.`requests`.`source`                           AS `source`,
                                      `npontupay`.`requests`.`full_amount`                      AS `full_amount`
                               from (`npontupay`.`clients`
                                      join `npontupay`.`requests`)
                               where (`npontupay`.`clients`.`id` = `npontupay`.`requests`.`client_id`));

