create view sms_log as
select `hellio`.`logs`.`id`                                                               AS `id`,
       `hellio`.`logs`.`bpid`                                                             AS `bpid`,
       `hellio`.`logs`.`job_id`                                                           AS `job_id`,
       `hellio`.`logs`.`user_id`                                                          AS `user_id`,
       `hellio`.`logs`.`username`                                                         AS `username`,
       `hellio`.`logs`.`msisdn`                                                           AS `msisdn`,
       `hellio`.`logs`.`network`                                                          AS `network`,
       `hellio`.`logs`.`sender`                                                           AS `sender`,
       `hellio`.`logs`.`h_message`                                                        AS `h_message`,
       `hellio`.`logs`.`message`                                                          AS `message`,
       `hellio`.`logs`.`sms_count`                                                        AS `sms_count`,
       `hellio`.`logs`.`submit_date`                                                      AS `submit_date`,
       `hellio`.`logs`.`created_by`                                                       AS `created_by`,
       `hellio`.`logs`.`response`                                                         AS `response`,
       `hellio`.`logs`.`originated`                                                       AS `originated`,
       `hellio`.`logs`.`refid`                                                            AS `refid`,
       `hellio`.`log_received`.`msgid`                                                    AS `msgid`,
       `hellio`.`log_received`.`delivery_time`                                            AS `delivery_time`,
       `hellio`.`log_received`.`error_code`                                               AS `error_code`,
       `hellio`.`log_received`.`error_msg`                                                AS `error_msg`,
       coalesce(`hellio`.`log_received`.`status`, `hellio`.`logs`.`status`)               AS `status`,
       coalesce(`hellio`.`log_received`.`delivery_date`, `hellio`.`logs`.`delivery_date`) AS `delivery_date`,
       `hellio`.`logs`.`created_at`                                                       AS `created_at`,
       `hellio`.`log_received`.`updated_at`                                               AS `updated_at`
from (`hellio`.`logs`
       left join `hellio`.`log_received` on ((`hellio`.`logs`.`id` = `hellio`.`log_received`.`id`)))
where (`hellio`.`logs`.`user_id` is not null);

