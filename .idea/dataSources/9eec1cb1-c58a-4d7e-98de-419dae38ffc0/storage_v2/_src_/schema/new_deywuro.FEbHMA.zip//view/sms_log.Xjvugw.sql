create view sms_log as
select `new_deywuro`.`logs`.`id`                                                                    AS `id`,
       `new_deywuro`.`logs`.`bpid`                                                                  AS `bpid`,
       `new_deywuro`.`logs`.`job_id`                                                                AS `job_id`,
       `new_deywuro`.`logs`.`user_id`                                                               AS `user_id`,
       `new_deywuro`.`logs`.`username`                                                              AS `username`,
       `new_deywuro`.`logs`.`msisdn`                                                                AS `msisdn`,
       `new_deywuro`.`logs`.`network`                                                               AS `network`,
       `new_deywuro`.`logs`.`sender`                                                                AS `sender`,
       `new_deywuro`.`logs`.`h_message`                                                             AS `h_message`,
       `new_deywuro`.`logs`.`message`                                                               AS `message`,
       `new_deywuro`.`logs`.`sms_count`                                                             AS `sms_count`,
       `new_deywuro`.`logs`.`submit_date`                                                           AS `submit_date`,
       `new_deywuro`.`logs`.`created_by`                                                            AS `created_by`,
       `new_deywuro`.`logs`.`response`                                                              AS `response`,
       `new_deywuro`.`logs`.`originated`                                                            AS `originated`,
       `new_deywuro`.`logs`.`refid`                                                                 AS `refid`,
       `new_deywuro`.`log_received`.`msgid`                                                         AS `msgid`,
       `new_deywuro`.`log_received`.`delivery_time`                                                 AS `delivery_time`,
       `new_deywuro`.`log_received`.`error_code`                                                    AS `error_code`,
       `new_deywuro`.`log_received`.`error_msg`                                                     AS `error_msg`,
       coalesce(`new_deywuro`.`log_received`.`status`, `new_deywuro`.`logs`.`status`)               AS `status`,
       coalesce(`new_deywuro`.`log_received`.`delivery_date`, `new_deywuro`.`logs`.`delivery_date`) AS `delivery_date`,
       `new_deywuro`.`logs`.`created_at`                                                            AS `created_at`,
       `new_deywuro`.`log_received`.`updated_at`                                                    AS `updated_at`
from (`new_deywuro`.`logs`
       left join `new_deywuro`.`log_received` on ((`new_deywuro`.`logs`.`id` = `new_deywuro`.`log_received`.`id`)))
where (`new_deywuro`.`logs`.`user_id` is not null);

