create view scheme_total_values as (select `scheme_raw_values`.`scheme_id` AS `scheme_id`,sum(`scheme_raw_values`.`net`) AS `net`
                                    from `haven_trust`.`scheme_raw_values`
                                    group by `scheme_raw_values`.`scheme_id`);

