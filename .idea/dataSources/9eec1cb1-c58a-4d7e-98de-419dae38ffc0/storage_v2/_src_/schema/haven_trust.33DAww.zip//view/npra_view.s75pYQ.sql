create view npra_view as
select `v`.`fullName`    AS `employer`,
       `v`.`id`          AS `employer_id`,
       `e`.`id`          AS `employee_id`,
       `e`.`fullName`    AS `employee`,
       `e`.`ssNumber`    AS `ssNumber`,
       `s`.`id`          AS `scheme_id`,
       `s`.`name`        AS `scheme`,
       `s`.`type`        AS `tier`,
       `e`.`nationality` AS `nationality`,
       `c`.`basicSalary` AS `salary`,
       `c`.`month`       AS `month`,
       `c`.`year`        AS `year`,
       `c`.`amount`      AS `amount`,
       `c`.`rate`        AS `rate`,
       `c`.`interest`    AS `interest`,
       `c`.`total`       AS `total`
from (((`haven_trust`.`contributions` `c` left join `haven_trust`.`employees` `e` on ((`c`.`employee_id` = `e`.`id`))) left join `haven_trust`.`employers` `v` on ((`e`.`employer_id` = `v`.`id`)))
       left join `haven_trust`.`schemes` `s` on ((`c`.`scheme_id` = `s`.`id`)));

