create view employer_contributions as
select `c`.`employer_id`   AS `employer_id`,
       `e`.`fullName`      AS `employer`,
       `c`.`month`         AS `month`,
       `c`.`year`          AS `year`,
       sum(`c`.`amount`)   AS `amount`,
       count(`c`.`amount`) AS `total`
from (`haven_trust`.`contributions` `c`
       join `haven_trust`.`employers` `e` on ((`c`.`employer_id` = `e`.`id`)))
group by `c`.`employer_id`,`e`.`fullName`,`c`.`year`,`c`.`month`;

