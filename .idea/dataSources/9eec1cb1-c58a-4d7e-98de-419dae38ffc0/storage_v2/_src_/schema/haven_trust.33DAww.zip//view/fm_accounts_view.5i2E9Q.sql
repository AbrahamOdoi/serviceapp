create view fm_accounts_view as
select `s`.`fundManager`              AS `fundManager`,
       `s`.`name`                     AS `scheme`,
       `s`.`id`                       AS `scheme_id`,
       coalesce(sum(`a`.`amount`), 0) AS `amount`
from (`haven_trust`.`schemes` `s`
       left join `haven_trust`.`fundmanagers_accounts` `a` on ((`s`.`id` = `a`.`scheme`)))
group by `s`.`name`,`s`.`id`,`s`.`fundManager`;

