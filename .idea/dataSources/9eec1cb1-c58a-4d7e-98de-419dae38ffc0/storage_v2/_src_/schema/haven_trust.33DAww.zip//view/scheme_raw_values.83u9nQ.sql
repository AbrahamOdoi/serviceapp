create view scheme_raw_values as (select `haven_trust`.`contributions`.`scheme_id`       AS `scheme_id`,
                                         `haven_trust`.`contributions`.`employee_id`     AS `employee_id`,
                                         max(`haven_trust`.`contributions`.`old_total`)  AS `total`,
                                         sum(`haven_trust`.`contributions`.`interest`)   AS `interest`,
                                         (max(`haven_trust`.`contributions`.`old_total`) +
                                          sum(`haven_trust`.`contributions`.`interest`)) AS `net`
                                  from `haven_trust`.`contributions`
                                  group by `haven_trust`.`contributions`.`employee_id`,`haven_trust`.`contributions`.`scheme_id`);

