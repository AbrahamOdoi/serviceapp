create view viewcontributionsool as (select `haven_trust`.`contributions`.`employee_id`     AS `employee_id`,
                                            `haven_trust`.`contributions`.`employer_id`     AS `employer_id`,
                                            `haven_trust`.`contributions`.`employer`        AS `employer`,
                                            `haven_trust`.`contributions`.`enrolmentNumber` AS `enrolmentNumber`,
                                            `haven_trust`.`contributions`.`month`           AS `month`,
                                            `haven_trust`.`contributions`.`year`            AS `year`,
                                            `haven_trust`.`contributions`.`amount`          AS `amount`,
                                            `haven_trust`.`employees`.`ssNumber`            AS `ssNumber`,
                                            `haven_trust`.`contributions`.`rate`            AS `rate`,
                                            `haven_trust`.`employees`.`fullName`            AS `fullName`,
                                            `haven_trust`.`employees`.`tier`                AS `tier`,
                                            `haven_trust`.`employers`.`scheme_id`           AS `scheme_id`
                                     from ((`haven_trust`.`contributions` join `haven_trust`.`employees` on ((
                                         `haven_trust`.`employees`.`id` = `haven_trust`.`contributions`.`employee_id`)))
                                            join `haven_trust`.`employers` on ((`haven_trust`.`employers`.`id` =
                                                                                `haven_trust`.`contributions`.`employer_id`))));

