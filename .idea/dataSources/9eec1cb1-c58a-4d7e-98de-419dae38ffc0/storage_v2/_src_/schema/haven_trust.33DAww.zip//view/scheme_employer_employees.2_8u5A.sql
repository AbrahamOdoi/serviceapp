create view scheme_employer_employees as (select `haven_trust`.`schemes`.`id`         AS `scheme_id`,
                                                 `haven_trust`.`schemes`.`name`       AS `scheme_name`,
                                                 `haven_trust`.`schemes`.`type`       AS `tier`,
                                                 `haven_trust`.`employers`.`fullName` AS `employer`,
                                                 `haven_trust`.`employers`.`id`       AS `employer_id`,
                                                 `haven_trust`.`employees`.`fullName` AS `employee`,
                                                 `haven_trust`.`employees`.`id`       AS `employee_id`
                                          from ((`haven_trust`.`schemes` join `haven_trust`.`employers` on ((`haven_trust`.`employers`.`scheme_id` = `haven_trust`.`schemes`.`id`)))
                                                 join `haven_trust`.`employees`
                                                      on ((`haven_trust`.`employees`.`employer_id` =
                                                           `haven_trust`.`employees`.`id`))));

