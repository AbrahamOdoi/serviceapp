create view caseOptions as
select `dbussd`.`cases`.`userId`          AS `userId`,
       `dbussd`.`cases`.`serviceCode`     AS `serviceCode`,
       `dbussd`.`cases`.`caseNumber`      AS `caseNumber`,
       `dbussd`.`cases`.`header`          AS `header`,
       `dbussd`.`cases`.`optionCount`     AS `optionCount`,
       `dbussd`.`cases`.`continue`        AS `continue`,
       `dbussd`.`cases`.`message`         AS `message`,
       `dbussd`.`cases`.`responseType`    AS `responseType`,
       `dbussd`.`options`.`value`         AS `value`,
       `dbussd`.`options`.`caseId`        AS `caseId`,
       `dbussd`.`options`.`parentId`      AS `parentId`,
       `dbussd`.`options`.`sendSms`       AS `sendSms`,
       `dbussd`.`options`.`smsMessage`    AS `smsMessage`,
       `dbussd`.`options`.`makePayment`   AS `makePayment`,
       `dbussd`.`options`.`paymentAmount` AS `paymentAmount`,
       `dbussd`.`options`.`created_at`    AS `created_at`
from (`dbussd`.`options`
       join `dbussd`.`cases` on ((`dbussd`.`options`.`caseId` = `dbussd`.`cases`.`id`)));

