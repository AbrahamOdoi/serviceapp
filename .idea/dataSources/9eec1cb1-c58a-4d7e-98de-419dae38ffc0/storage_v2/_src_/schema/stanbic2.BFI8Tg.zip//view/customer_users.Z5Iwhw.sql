create view customer_users as
select `stanbic2`.`users`.`first_name`               AS `first_name`,
       `stanbic2`.`users`.`middle_name`              AS `middle_name`,
       `stanbic2`.`users`.`last_name`                AS `last_name`,
       `stanbic2`.`users`.`email`                    AS `email`,
       `stanbic2`.`users`.`username`                 AS `username`,
       `stanbic2`.`users`.`password`                 AS `password`,
       `stanbic2`.`users`.`id`                       AS `user_id`,
       `stanbic2`.`customers`.`id`                   AS `customer_id`,
       `stanbic2`.`customers`.`phone_no`             AS `phone_no`,
       `stanbic2`.`customers`.`account_number`       AS `account_number`,
       `stanbic2`.`customers`.`gender`               AS `gender`,
       `stanbic2`.`customers`.`marital_status_id`    AS `marital_status_id`,
       `stanbic2`.`customers`.`date_of_birth`        AS `date_of_birth`,
       `stanbic2`.`customers`.`id_type_id`           AS `id_type_id`,
       `stanbic2`.`customers`.`id_number`            AS `id_number`,
       `stanbic2`.`customers`.`occupation`           AS `occupation`,
       `stanbic2`.`customers`.`next_of_kin`          AS `next_of_kin`,
       `stanbic2`.`customers`.`next_of_kin_relation` AS `next_of_kin_relation`
from (`stanbic2`.`customers`
       join `stanbic2`.`users` on ((`stanbic2`.`customers`.`user_id` = `stanbic2`.`users`.`id`)));

