create view sms_log as
select `samhellio`.`logs`.`id`                                                                  AS `id`,
       `samhellio`.`logs`.`job_id`                                                              AS `job_id`,
       `samhellio`.`logs`.`bpid`                                                                AS `bpid`,
       `samhellio`.`logs`.`user_id`                                                             AS `user_id`,
       `samhellio`.`logs`.`username`                                                            AS `username`,
       `samhellio`.`logs`.`msisdn`                                                              AS `msisdn`,
       `samhellio`.`logs`.`network`                                                             AS `network`,
       `samhellio`.`logs`.`sender`                                                              AS `sender`,
       `samhellio`.`logs`.`h_message`                                                           AS `h_message`,
       `samhellio`.`logs`.`message`                                                             AS `message`,
       `samhellio`.`logs`.`sms_count`                                                           AS `sms_count`,
       `samhellio`.`logs`.`submit_date`                                                         AS `submit_date`,
       `samhellio`.`logs`.`created_by`                                                          AS `created_by`,
       `samhellio`.`logs`.`response`                                                            AS `response`,
       `samhellio`.`logs`.`originated`                                                          AS `originated`,
       `samhellio`.`logs`.`refid`                                                               AS `refid`,
       `samhellio`.`log_received`.`msgid`                                                       AS `msgid`,
       `samhellio`.`log_received`.`delivery_time`                                               AS `delivery_time`,
       `samhellio`.`log_received`.`error_code`                                                  AS `error_code`,
       `samhellio`.`log_received`.`error_msg`                                                   AS `error_msg`,
       coalesce(`samhellio`.`log_received`.`status`, `samhellio`.`logs`.`status`)               AS `status`,
       coalesce(`samhellio`.`log_received`.`delivery_date`, `samhellio`.`logs`.`delivery_date`) AS `delivery_date`,
       `samhellio`.`logs`.`created_at`                                                          AS `created_at`,
       `samhellio`.`log_received`.`updated_at`                                                  AS `updated_at`
from (`samhellio`.`logs`
       left join `samhellio`.`log_received` on ((`samhellio`.`logs`.`msgid` = `samhellio`.`log_received`.`msgid`)))
where (`samhellio`.`logs`.`user_id` is not null);

