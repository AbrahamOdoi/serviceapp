create view excess_view as
select `c`.`id`                                              AS `id`,
       now()                                                 AS `date`,
       `c`.`clientId`                                        AS `clientId`,
       `c`.`id`                                              AS `client_id`,
       `uc`.`name`                                           AS `client_name`,
       `c`.`location`                                        AS `location`,
       (coalesce(`c`.`amount`, 0) * coalesce(`c`.`bins`, 0)) AS `ar_default`,
       coalesce(`c`.`amount_brought_forward`, 0)             AS `bf_amount`,
       `v`.`bills`                                           AS `total_amount`,
       `v`.`payments`                                        AS `payment_amount`,
       `v`.`amt_bf`                                          AS `excess`,
       `ua`.`name`                                           AS `agent_name`,
       `a`.`id`                                              AS `agent_id`
from ((((`goldmine`.`client_statement_view` `v` left join `goldmine`.`clients` `c` on ((`c`.`id` = `v`.`client_id`))) left join `goldmine`.`users` `uc` on ((`uc`.`id` = `c`.`user_id`))) left join `goldmine`.`agents` `a` on ((`a`.`id` = `c`.`agent_id`)))
       left join `goldmine`.`users` `ua` on ((`ua`.`id` = `a`.`user_id`)))
where (`v`.`amt_bf` > 0)
order by `c`.`id`;

