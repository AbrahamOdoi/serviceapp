create view client_bill_amount_view as
select `p`.`client_id` AS `client_id`,sum(`p`.`bill`) AS `bill_amount`,`p`.`date` AS `created_at`
from `goldmine`.`statement_view` `p`
group by `p`.`client_id`;

