create view monthly_statement_view as
select `statement_view`.`client_id`     AS `client_id`,
       left(`statement_view`.`date`, 7) AS `date`,
       sum(`statement_view`.`bill`)     AS `bill`,
       sum(`statement_view`.`payment`)  AS `payment`,
       `statement_view`.`comment`       AS `comment`,
       sum(`statement_view`.`old_bal`)  AS `old_bal`,
       sum(`statement_view`.`new_bal`)  AS `new_bal`
from `goldmine`.`statement_view`
group by `statement_view`.`client_id`,left(`statement_view`.`date`, 7)
order by left(`statement_view`.`date`, 7);

