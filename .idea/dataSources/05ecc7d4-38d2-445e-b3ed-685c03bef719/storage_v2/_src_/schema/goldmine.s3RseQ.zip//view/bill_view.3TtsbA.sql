create view bill_view as
select `goldmine`.`bill_histories`.`id`           AS `id`,
       `goldmine`.`clients`.`clientId`            AS `clientId`,
       `u`.`name`                                 AS `name`,
       `goldmine`.`bill_histories`.`amount`       AS `amount`,
       `goldmine`.`bill_histories`.`comment`      AS `comment`,
       `goldmine`.`bill_histories`.`year`         AS `year`,
       `goldmine`.`bill_histories`.`month`        AS `month`,
       `goldmine`.`bill_histories`.`bill_date`    AS `bill_date`,
       `goldmine`.`bill_histories`.`generated_by` AS `generated_by`,
       `goldmine`.`bill_histories`.`status`       AS `status`,
       `goldmine`.`bill_histories`.`client_id`    AS `client_id`,
       ifnull((select `cs`.`service_id`
               from `goldmine`.`client_service` `cs`
               where (`cs`.`client_id` = `goldmine`.`bill_histories`.`client_id`)
               limit 1), 0)                       AS `service_id`
from ((`goldmine`.`bill_histories` left join `goldmine`.`clients` on ((`goldmine`.`clients`.`id` = `goldmine`.`bill_histories`.`client_id`)))
       left join `goldmine`.`users` `u` on ((`goldmine`.`clients`.`user_id` = `u`.`id`)));

