create view payment_view as
select `goldmine`.`payment_histories`.`id`              AS `id`,
       `goldmine`.`payment_histories`.`client_id`       AS `client_id`,
       `goldmine`.`payment_histories`.`payment_type_id` AS `payment_type_id`,
       `goldmine`.`payment_histories`.`amount`          AS `amount`,
       `goldmine`.`payment_histories`.`service_id`      AS `service_id`,
       `goldmine`.`payment_histories`.`year`            AS `year`,
       `goldmine`.`payment_histories`.`month`           AS `month`,
       `goldmine`.`payment_histories`.`payment_date`    AS `payment_date`,
       `goldmine`.`payment_histories`.`received_by`     AS `received_by`,
       `goldmine`.`payment_histories`.`description`     AS `description`,
       `goldmine`.`clients`.`clientId`                  AS `clientId`,
       `goldmine`.`users`.`name`                        AS `name`,
       `goldmine`.`payment_types`.`name`                AS `payment_type`,
       `goldmine`.`services`.`name`                     AS `service`
from ((((`goldmine`.`payment_histories` left join `goldmine`.`clients` on ((`goldmine`.`clients`.`id` =
                                                                            `goldmine`.`payment_histories`.`client_id`))) left join `goldmine`.`users` on ((`goldmine`.`users`.`id` = `goldmine`.`clients`.`user_id`))) join `goldmine`.`payment_types` on ((
    `goldmine`.`payment_histories`.`payment_type_id` = `goldmine`.`payment_types`.`id`)))
       join `goldmine`.`services` on ((`goldmine`.`payment_histories`.`service_id` = `goldmine`.`services`.`id`)));

