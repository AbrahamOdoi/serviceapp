create view atb_vs_ab_view as (select `c`.`id`                    AS `client_id`,
                                      `u`.`name`                  AS `name`,
                                      `h`.`month`                 AS `month`,
                                      `h`.`year`                  AS `year`,
                                      `h`.`service_id`            AS `service_id`,
                                      `c`.`amount`                AS `amount`,
                                      `c`.`bins`                  AS `bins`,
                                      (`c`.`amount` * `c`.`bins`) AS `amt_to_bill`,
                                      `h`.`amount`                AS `amt_billed`,
                                      `h`.`bill_date`             AS `bill_date`,
                                      `h`.`comment`               AS `comment`,
                                      `h`.`generated_by`          AS `generated_by`
                               from ((`goldmine`.`bill_histories` `h` left join `goldmine`.`clients` `c` on ((`c`.`id` = `h`.`client_id`)))
                                      left join `goldmine`.`users` `u` on ((`u`.`id` = `c`.`user_id`))));

