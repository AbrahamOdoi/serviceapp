create view statement_view as (select `goldmine`.`payment_histories`.`client_id`                                    AS `client_id`,
                                      `goldmine`.`payment_histories`.`payment_date`                                 AS `date`,
                                      0                                                                             AS `bill`,
                                      `goldmine`.`payment_histories`.`amount`                                       AS `payment`,
                                      `goldmine`.`payment_histories`.`old_bal`                                      AS `old_bal`,
                                      `goldmine`.`payment_histories`.`new_bal`                                      AS `new_bal`,
                                      coalesce(`goldmine`.`payment_histories`.`description`,
                                               'Payment for Service')                                               AS `comment`
                               from `goldmine`.`payment_histories`
                               where (`goldmine`.`payment_histories`.`client_id` is not null))
                              union
                              (select `goldmine`.`bill_histories`.`client_id`        AS `client_id`,
                                      `goldmine`.`bill_histories`.`bill_date`        AS `date`,
                                      `goldmine`.`bill_histories`.`amount`           AS `bill`,
                                      0                                              AS `payment`,
                                      `goldmine`.`bill_histories`.`old_bal`          AS `old_bal`,
                                      `goldmine`.`bill_histories`.`new_bal`          AS `new_bal`,
                                      coalesce(`goldmine`.`bill_histories`.`comment`,
                                               'Service Charge / Debit Transaction') AS `comment`
                               from `goldmine`.`bill_histories`
                               where (`goldmine`.`bill_histories`.`client_id` is not null))
                              order by `date`;

