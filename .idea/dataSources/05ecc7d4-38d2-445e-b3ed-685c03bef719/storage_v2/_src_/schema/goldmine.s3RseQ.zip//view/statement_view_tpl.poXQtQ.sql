create view statement_view_tpl as select `goldmine`.`bill_histories`.`client_id`        AS `client_id`,
                                         `goldmine`.`bill_histories`.`bill_date`        AS `date`,
                                         `goldmine`.`bill_histories`.`amount`           AS `bill`,
                                         0                                              AS `payment`,
                                         coalesce(`goldmine`.`bill_histories`.`comment`,
                                                  'Service Charge / Debit Transaction') AS `comment`,
                                         `goldmine`.`bill_histories`.`old_bal`          AS `old_bal`,
                                         `goldmine`.`bill_histories`.`new_bal`          AS `new_bal`
                                  from `goldmine`.`bill_histories`
                                  union
                                  select `goldmine`.`payment_histories`.`client_id`    AS `client_id`,
                                         `goldmine`.`payment_histories`.`payment_date` AS `date`,
                                         0                                             AS `bill`,
                                         `goldmine`.`payment_histories`.`amount`       AS `payment`,
                                         coalesce(`goldmine`.`payment_histories`.`description`,
                                                  'Payment for Service')               AS `comment`,
                                         `goldmine`.`payment_histories`.`old_bal`      AS `old_bal`,
                                         `goldmine`.`payment_histories`.`new_bal`      AS `new_bal`
                                  from `goldmine`.`payment_histories`;

