create view district_debtor_view as
select `p`.`date`     AS `date`,
       `d`.`name`     AS `district`,
       `d`.`id`       AS `district_id`,
       `p`.`clientId` AS `client_no`,
       `u`.`name`     AS `name`,
       NULL           AS `service`,
       `p`.`balance`  AS `amount`,
       NULL           AS `received_by`,
       `c`.`agent_id` AS `agent_id`
from ((((`goldmine`.`debtors_view` `p` join `goldmine`.`clients` `c` on ((`p`.`client_id` = `c`.`id`))) join `goldmine`.`users` `u` on ((`u`.`id` = `c`.`user_id`))) join `goldmine`.`districts` `d` on ((`d`.`id` = `c`.`district_id`)))
       join `goldmine`.`regions` `r` on ((`r`.`id` = `d`.`region_id`)))
group by `u`.`name`;

