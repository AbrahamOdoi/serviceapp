create view client_statement_view as
select `c`.`clientId`                                                                AS `clientId`,
       `uc`.`name`                                                                   AS `name`,
       `c`.`location`                                                                AS `location`,
       `statement_view`.`client_id`                                                  AS `client_id`,
       coalesce((`c`.`amount` * `c`.`bins`))                                         AS `amt_rec`,
       coalesce(sum(`statement_view`.`bill`), 0)                                     AS `bills`,
       coalesce(sum(`statement_view`.`payment`), 0)                                  AS `payments`,
       coalesce((sum(`statement_view`.`payment`) - sum(`statement_view`.`bill`)), 0) AS `amt_bf`,
       `ua`.`name`                                                                   AS `agent_name`
from ((((`goldmine`.`statement_view` join `goldmine`.`clients` `c` on ((`c`.`id` = `statement_view`.`client_id`))) left join `goldmine`.`users` `uc` on ((`uc`.`id` = `c`.`user_id`))) join `goldmine`.`agents` `a` on ((`c`.`agent_id` = `a`.`id`)))
       join `goldmine`.`users` `ua` on ((`ua`.`id` = `a`.`user_id`)))
group by `statement_view`.`client_id`
order by `statement_view`.`date`;

