create view sms_log as
select `kannel`.`MT`.`session_esme`                   AS `username`,
       `kannel`.`MT`.`msg_id`                         AS `msg_id`,
       from_unixtime(`kannel`.`MT`.`msg_timestamp`)   AS `submit_date`,
       `kannel`.`MT`.`state`                          AS `status`,
       from_unixtime(`kannel`.`MT`.`state_timestamp`) AS `delivery_time`,
       unhex(`kannel`.`MT`.`smpp_short_message`)      AS `message`,
       `kannel`.`MT`.`smpp_destination_addr`          AS `msisdn`,
       `kannel`.`MT`.`smpp_source_add`                AS `sender`
from `kannel`.`MT`;

