create view weekly_traffic_view as
select left(from_unixtime(`kannel`.`MT`.`msg_timestamp`), 10) AS `date`,
       (case
          when (`kannel`.`MT`.`state` like '%DELIVRD%') then 'DELIVRD'
          when (`kannel`.`MT`.`state` like '%UNDELI%') then 'UNDELIV'
          when (`kannel`.`MT`.`state` like '%ACK%') then 'ACK'
          when (`kannel`.`MT`.`state` like '%EJECTD%') then 'REJECTD'
          when (`kannel`.`MT`.`state` like '%EXPIRED%') then 'EXPIRED'
          else 'UNKNOWN' end)                                 AS `status`,
       count(`kannel`.`MT`.`state`)                           AS `total`
from `kannel`.`MT`
where (from_unixtime(`kannel`.`MT`.`msg_timestamp`) > (curdate() - interval 7 day))
group by (case
            when (`kannel`.`MT`.`state` like '%DELIVRD%') then 'DELIVRD'
            when (`kannel`.`MT`.`state` like '%UNDELI%') then 'UNDELIV'
            when (`kannel`.`MT`.`state` like '%ACK%') then 'ACK'
            when (`kannel`.`MT`.`state` like '%EJECTD%') then 'REJECTD'
            when (`kannel`.`MT`.`state` like '%EXPIRED%') then 'EXPIRED'
            else 'UNKNOWN' end),left(from_unixtime(`kannel`.`MT`.`msg_timestamp`), 10)
order by left(from_unixtime(`kannel`.`MT`.`msg_timestamp`), 10);

