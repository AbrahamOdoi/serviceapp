create view customer_users as
select `stanbic`.`users`.`first_name`               AS `first_name`,
       `stanbic`.`users`.`middle_name`              AS `middle_name`,
       `stanbic`.`users`.`last_name`                AS `last_name`,
       `stanbic`.`users`.`email`                    AS `email`,
       `stanbic`.`users`.`username`                 AS `username`,
       `stanbic`.`users`.`password`                 AS `password`,
       `stanbic`.`users`.`id`                       AS `user_id`,
       `stanbic`.`customers`.`id`                   AS `customer_id`,
       `stanbic`.`customers`.`phone_no`             AS `phone_no`,
       `stanbic`.`customers`.`account_number`       AS `account_number`,
       `stanbic`.`customers`.`gender`               AS `gender`,
       `stanbic`.`customers`.`marital_status_id`    AS `marital_status_id`,
       `stanbic`.`customers`.`date_of_birth`        AS `date_of_birth`,
       `stanbic`.`customers`.`id_type_id`           AS `id_type_id`,
       `stanbic`.`customers`.`id_number`            AS `id_number`,
       `stanbic`.`customers`.`occupation`           AS `occupation`,
       `stanbic`.`customers`.`next_of_kin`          AS `next_of_kin`,
       `stanbic`.`customers`.`next_of_kin_relation` AS `next_of_kin_relation`
from (`stanbic`.`customers`
       join `stanbic`.`users` on ((`stanbic`.`customers`.`user_id` = `stanbic`.`users`.`id`)));

