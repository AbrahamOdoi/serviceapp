create view sms_log as
select `deywuro`.`logs`.`id`                                                                AS `id`,
       `deywuro`.`logs`.`job_id`                                                            AS `job_id`,
       `deywuro`.`logs`.`user_id`                                                           AS `user_id`,
       `deywuro`.`logs`.`username`                                                          AS `username`,
       `deywuro`.`logs`.`msisdn`                                                            AS `msisdn`,
       `deywuro`.`logs`.`network`                                                           AS `network`,
       `deywuro`.`logs`.`sender`                                                            AS `sender`,
       `deywuro`.`logs`.`h_message`                                                         AS `h_message`,
       `deywuro`.`logs`.`message`                                                           AS `message`,
       `deywuro`.`logs`.`sms_count`                                                         AS `sms_count`,
       `deywuro`.`logs`.`submit_date`                                                       AS `submit_date`,
       `deywuro`.`logs`.`created_by`                                                        AS `created_by`,
       `deywuro`.`logs`.`response`                                                          AS `response`,
       `deywuro`.`logs`.`originated`                                                        AS `originated`,
       `deywuro`.`logs`.`refid`                                                             AS `refid`,
       `deywuro`.`log_received`.`msgid`                                                     AS `msgid`,
       `deywuro`.`log_received`.`delivery_time`                                             AS `delivery_time`,
       `deywuro`.`log_received`.`error_code`                                                AS `error_code`,
       `deywuro`.`log_received`.`error_msg`                                                 AS `error_msg`,
       coalesce(`deywuro`.`log_received`.`status`, `deywuro`.`logs`.`status`)               AS `status`,
       coalesce(`deywuro`.`log_received`.`delivery_date`, `deywuro`.`logs`.`delivery_date`) AS `delivery_date`,
       `deywuro`.`logs`.`created_at`                                                        AS `created_at`,
       `deywuro`.`log_received`.`updated_at`                                                AS `updated_at`
from (`deywuro`.`logs`
       left join `deywuro`.`log_received` on ((`deywuro`.`logs`.`msgid` = `deywuro`.`log_received`.`msgid`)))
where (`deywuro`.`logs`.`user_id` is not null);

